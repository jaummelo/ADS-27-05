export class CreateBookDto {
    name: string;
    author: string;
    value: number;
    ISBN: string;
}
